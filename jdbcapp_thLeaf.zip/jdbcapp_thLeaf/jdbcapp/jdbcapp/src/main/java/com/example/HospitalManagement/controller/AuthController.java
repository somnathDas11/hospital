package com.example.HospitalManagement.controller;

import com.example.HospitalManagement.model.Paitent;
import com.example.HospitalManagement.model.Role;
import com.example.HospitalManagement.model.User;
import com.example.HospitalManagement.service.PaitentService;
import com.example.HospitalManagement.service.UserService;
import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

@Controller

@RequiredArgsConstructor
public class AuthController {



    private  final UserService userService;
    private  final PaitentService paitentService;

    @GetMapping("/")
    public String home()
    {
        return "index";
    }


    @GetMapping("/login")
    public String login(HttpSession session)
    {

        //session.setAttribute("uniqueId",  uniqueId);
        return "login";
    }

    @GetMapping("/register")

    //public String registerForm(Model model)
    public String registerForm(Model model) {
        model.addAttribute("patient", new Paitent());
        //System.out.println(" get reg called");
        return "register";
    }

    @PostMapping("/register")
    public String registerPatient(@Valid @ModelAttribute("patient") Paitent paitent,
                                  BindingResult result,
                                  @RequestParam String password,
                                  @RequestParam String confirmPassword,
                                  Model model) {

        if (result.hasErrors()) {
            //System.out.println(" post err reg called");
            return "register";

        }

        if (!password.equals(confirmPassword)) {
            model.addAttribute("error", "Passwords do not match");

            //System.out.println(" post passworderror reg called");
            return "register";
        }

        // Create user
        User user = userService.createUser(password, Role.PATIENT);

        // Link patient to use;
        paitent.setUser(user);
        paitentService.savePaitent(paitent);

        model.addAttribute("message",
                "Registration successful. Your ID is: " + user.getUniqueId());
        //System.out.println(" post reg called" + user.getUniqueId());
        return "register";
    }

    @GetMapping("/dashboard")
    public String dashboard(@AuthenticationPrincipal UserDetails userDetails, Model model) {
        model.addAttribute("username", userDetails.getUsername());
        return "dashboard";
    }

}