package com.example.HospitalManagement.config;

import com.example.HospitalManagement.service.CustomUserDetailsService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;


@Configuration
@EnableWebSecurity
@RequiredArgsConstructor

public class SequrityConfig {

    private final CustomUserDetailsService userDetailsService;

        @Bean
        public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
            http
                    // CSRF is enabled by default, so we just configure URLs
                    .authorizeHttpRequests(auth -> auth
                            // allow public access to home, login, register, and static resources
                            .requestMatchers("/", "/login", "/register", "/css/**", "/js/**").permitAll()
                            // only admins may access admin paths
                            .requestMatchers("/admin/**").hasRole("ADMIN")
                            // only patients may access patient paths
                            .requestMatchers("/patient/**").hasRole("PATIENT")
                            // any other request must be authenticated
                            .anyRequest().authenticated()
                    )
                    .formLogin(form -> form
                            .loginPage("/login")    // custom login page path
                            .defaultSuccessUrl("/dashboard", true)
                            .permitAll()
                    )
                    .logout(logout -> logout
                            .logoutUrl("/logout")
                            .logoutSuccessUrl("/")
                            .permitAll()
                    );

            return http.build();
        }

        @Bean
        public AuthenticationManager authenticationManager(HttpSecurity http) throws Exception {
            AuthenticationManagerBuilder auth =
                    http.getSharedObject(AuthenticationManagerBuilder.class);

            auth.userDetailsService(userDetailsService)
                    .passwordEncoder(passwordEncoder());

            return auth.build();
        }

        @Bean
        public PasswordEncoder passwordEncoder() {
            return new BCryptPasswordEncoder();
        }
    }



