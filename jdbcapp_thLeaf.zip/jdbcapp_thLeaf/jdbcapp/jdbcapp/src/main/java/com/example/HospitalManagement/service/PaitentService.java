package com.example.HospitalManagement.service;

import com.example.HospitalManagement.model.Paitent;
import com.example.HospitalManagement.repo.PaitentRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class PaitentService {

    private final PaitentRepository repo;

    public void savePaitent(Paitent paitent) {

        repo.save(paitent);

    }

    public Optional<Paitent> findByUniqueId(String uniqueId) {
        return repo.findByUser_UniqueId(uniqueId);
    }

    public List<Paitent> search(String first, String last) {
        return repo
                .findByFirstNameContainingIgnoreCaseAndLastNameContainingIgnoreCase(first, last);
    }

    public Optional<Paitent> findById(Long id) {
        return repo.findById(id);
    }
}
