package com.example.HospitalManagement.repo;

import com.example.HospitalManagement.model.Paitent;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface PaitentRepository extends JpaRepository<Paitent, Long> {



    Optional<Paitent> findByUser_UniqueId(String uniqueId);

    // Search by first and last name (partial + case insensitive)
    List<Paitent> findByFirstNameContainingIgnoreCaseAndLastNameContainingIgnoreCase(
            String firstName,
            String lastName
    );

    // Optional: Search by mobile number
    List<Paitent> findByMobileNumber(String mobileNumber);
}
