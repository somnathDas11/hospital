package com.example.HospitalManagement.service;

import com.example.HospitalManagement.model.Role;
import com.example.HospitalManagement.model.User;
import com.example.HospitalManagement.repo.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.UUID;

@Service
@RequiredArgsConstructor
public class UserService {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    public User createUser(String password, Role role) {

        User user = new User();
        user.setUniqueId("UID-" + UUID.randomUUID().toString().replace("-", "").substring(0, 10));
        user.setPassword(passwordEncoder.encode(password));
        user.setRole(role);

        return userRepository.save(user);
    }
}

