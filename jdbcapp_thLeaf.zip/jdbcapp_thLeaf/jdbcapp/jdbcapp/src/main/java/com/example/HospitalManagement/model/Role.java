package com.example.HospitalManagement.model;

public enum Role {
    ADMIN,
    PATIENT
}
